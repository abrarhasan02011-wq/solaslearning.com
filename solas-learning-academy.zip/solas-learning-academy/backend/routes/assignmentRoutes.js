const express = require("express");
const path = require("path");
const fs = require("fs");
const Assignment = require("../models/Assignment");
const Submission = require("../models/Submission");
const Course = require("../models/Course");
const { protect, authorize } = require("../middleware/auth");
const { assignmentUpload } = require("../middleware/upload");

const router = express.Router();

// @route   POST /api/assignments/:courseId
// @desc    Teacher: create a new assignment (optionally attach a file)
router.post(
  "/:courseId",
  protect,
  authorize("teacher", "admin"),
  assignmentUpload.single("attachment"),
  async (req, res) => {
    try {
      const course = await Course.findById(req.params.courseId);
      if (!course) return res.status(404).json({ message: "Course not found" });

      const { title, description, dueDate, maxMarks } = req.body;
      if (!title || !dueDate) {
        return res.status(400).json({ message: "Title and due date are required" });
      }

      const assignment = await Assignment.create({
        course: course._id,
        createdBy: req.user._id,
        title,
        description,
        dueDate,
        maxMarks: maxMarks || 100,
        attachmentPath: req.file ? `/uploads/assignments/${req.file.filename}` : "",
      });

      res.status(201).json(assignment);
    } catch (err) {
      res.status(500).json({ message: "Server error creating assignment", error: err.message });
    }
  }
);

// @route   GET /api/assignments/:courseId
router.get("/:courseId", protect, async (req, res) => {
  try {
    const assignments = await Assignment.find({ course: req.params.courseId }).sort({
      dueDate: 1,
    });
    res.json(assignments);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// @route   POST /api/assignments/:id/submit
// @desc    Student: submit (or resubmit) their work for an assignment
router.post(
  "/:id/submit",
  protect,
  authorize("student"),
  assignmentUpload.single("file"),
  async (req, res) => {
    try {
      const assignment = await Assignment.findById(req.params.id);
      if (!assignment) return res.status(404).json({ message: "Assignment not found" });
      if (!req.file) return res.status(400).json({ message: "No file uploaded (field name must be 'file')" });

      const isLate = new Date() > new Date(assignment.dueDate);

      const existing = await Submission.findOne({
        assignment: assignment._id,
        student: req.user._id,
      });

      if (existing) {
        // remove old file, replace with new submission
        const oldPath = path.join(__dirname, "..", existing.filePath);
        if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);

        existing.filePath = `/uploads/assignments/${req.file.filename}`;
        existing.fileName = req.file.originalname;
        existing.submittedAt = new Date();
        existing.status = isLate ? "late" : "submitted";
        existing.marksObtained = null;
        existing.feedback = "";
        await existing.save();
        return res.json(existing);
      }

      const submission = await Submission.create({
        assignment: assignment._id,
        student: req.user._id,
        filePath: `/uploads/assignments/${req.file.filename}`,
        fileName: req.file.originalname,
        status: isLate ? "late" : "submitted",
      });

      res.status(201).json(submission);
    } catch (err) {
      res.status(500).json({ message: "Server error submitting assignment", error: err.message });
    }
  }
);

// @route   GET /api/assignments/:id/submissions
// @desc    Teacher: view all submissions for an assignment
router.get("/:id/submissions", protect, authorize("teacher", "admin"), async (req, res) => {
  try {
    const submissions = await Submission.find({ assignment: req.params.id }).populate(
      "student",
      "name email"
    );
    res.json(submissions);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// @route   GET /api/assignments/submission/mine/:assignmentId
// @desc    Student: view my own submission status for an assignment
router.get("/submission/mine/:assignmentId", protect, authorize("student"), async (req, res) => {
  try {
    const submission = await Submission.findOne({
      assignment: req.params.assignmentId,
      student: req.user._id,
    });
    res.json(submission || null);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// @route   PATCH /api/assignments/submissions/:submissionId/grade
// @desc    Teacher: grade a submission
router.patch(
  "/submissions/:submissionId/grade",
  protect,
  authorize("teacher", "admin"),
  async (req, res) => {
    try {
      const { marksObtained, feedback } = req.body;
      const submission = await Submission.findByIdAndUpdate(
        req.params.submissionId,
        { marksObtained, feedback, status: "graded" },
        { new: true }
      );
      if (!submission) return res.status(404).json({ message: "Submission not found" });
      res.json(submission);
    } catch (err) {
      res.status(500).json({ message: "Server error", error: err.message });
    }
  }
);

// @route   GET /api/assignments/download/:submissionId
router.get("/download/:submissionId", protect, async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.submissionId);
    if (!submission) return res.status(404).json({ message: "Submission not found" });

    const absolutePath = path.join(__dirname, "..", submission.filePath);
    if (!fs.existsSync(absolutePath)) {
      return res.status(404).json({ message: "File missing on server" });
    }
    res.download(absolutePath, submission.fileName);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

module.exports = router;
