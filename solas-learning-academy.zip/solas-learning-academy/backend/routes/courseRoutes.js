const express = require("express");
const crypto = require("crypto");
const Course = require("../models/Course");
const { protect, authorize } = require("../middleware/auth");

const router = express.Router();

const generateJoinCode = () =>
  crypto.randomBytes(3).toString("hex").toUpperCase(); // e.g. "A1B2C3"

// @route   POST /api/courses
// @desc    Teacher/Admin: create a new course/class
router.post("/", protect, authorize("teacher", "admin"), async (req, res) => {
  try {
    const { title, description, subject, price, meetingLink, schedule, thumbnail } = req.body;
    if (!title) return res.status(400).json({ message: "Course title is required" });

    let joinCode = generateJoinCode();
    // ensure uniqueness (extremely unlikely to collide, but be safe)
    while (await Course.findOne({ joinCode })) {
      joinCode = generateJoinCode();
    }

    const course = await Course.create({
      title,
      description,
      subject,
      price: price || 0,
      meetingLink,
      schedule,
      thumbnail,
      teacher: req.user.role === "admin" ? req.body.teacher : req.user._id,
      joinCode,
    });

    res.status(201).json(course);
  } catch (err) {
    res.status(500).json({ message: "Server error creating course", error: err.message });
  }
});

// @route   GET /api/courses
// @desc    List courses. Students see published courses; teachers see their own; admin sees all.
router.get("/", protect, async (req, res) => {
  try {
    let filter = { isPublished: true };
    if (req.user.role === "teacher") filter = { teacher: req.user._id };
    if (req.user.role === "admin") filter = {};

    const courses = await Course.find(filter)
      .populate("teacher", "name email")
      .sort({ createdAt: -1 });
    res.json(courses);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// @route   GET /api/courses/mine
// @desc    Student: courses I'm enrolled in. Teacher: courses I teach.
router.get("/mine", protect, async (req, res) => {
  try {
    let courses;
    if (req.user.role === "student") {
      courses = await Course.find({ students: req.user._id }).populate("teacher", "name email");
    } else if (req.user.role === "teacher") {
      courses = await Course.find({ teacher: req.user._id });
    } else {
      courses = await Course.find();
    }
    res.json(courses);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// @route   GET /api/courses/:id
router.get("/:id", protect, async (req, res) => {
  try {
    const course = await Course.findById(req.params.id)
      .populate("teacher", "name email bio")
      .populate("students", "name email");
    if (!course) return res.status(404).json({ message: "Course not found" });
    res.json(course);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// @route   POST /api/courses/join
// @desc    Student: join a class using its join code (only works for free courses;
//          paid courses should go through /api/payments/checkout first)
router.post("/join", protect, authorize("student"), async (req, res) => {
  try {
    const { joinCode } = req.body;
    if (!joinCode) return res.status(400).json({ message: "Join code is required" });

    const course = await Course.findOne({ joinCode: joinCode.toUpperCase() });
    if (!course) return res.status(404).json({ message: "Invalid join code" });

    if (course.students.includes(req.user._id)) {
      return res.status(400).json({ message: "You are already enrolled in this class" });
    }

    if (course.price > 0) {
      return res.status(402).json({
        message: "This is a paid class. Please complete payment before joining.",
        coursePrice: course.price,
        courseId: course._id,
      });
    }

    course.students.push(req.user._id);
    await course.save();

    req.user.enrolledCourses.push(course._id);
    await req.user.save();

    res.json({ message: "Successfully joined the class", course });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// @route   PUT /api/courses/:id
// @desc    Teacher/Admin: update course details (meeting link, schedule, etc.)
router.put("/:id", protect, authorize("teacher", "admin"), async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).json({ message: "Course not found" });
    if (req.user.role === "teacher" && String(course.teacher) !== String(req.user._id)) {
      return res.status(403).json({ message: "You can only edit your own courses" });
    }

    const fields = ["title", "description", "subject", "price", "meetingLink", "schedule", "thumbnail", "isPublished"];
    fields.forEach((f) => {
      if (req.body[f] !== undefined) course[f] = req.body[f];
    });

    await course.save();
    res.json(course);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// @route   DELETE /api/courses/:id
router.delete("/:id", protect, authorize("teacher", "admin"), async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).json({ message: "Course not found" });
    if (req.user.role === "teacher" && String(course.teacher) !== String(req.user._id)) {
      return res.status(403).json({ message: "You can only delete your own courses" });
    }
    await course.deleteOne();
    res.json({ message: "Course deleted" });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

module.exports = router;
