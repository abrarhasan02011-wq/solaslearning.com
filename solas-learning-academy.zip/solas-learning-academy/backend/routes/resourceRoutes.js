const express = require("express");
const path = require("path");
const fs = require("fs");
const Resource = require("../models/Resource");
const Course = require("../models/Course");
const { protect, authorize } = require("../middleware/auth");
const { resourceUpload } = require("../middleware/upload");

const router = express.Router();

// @route   POST /api/resources/:courseId
// @desc    Teacher/Admin: upload a resource file (notes, slides, pdf, video, etc.)
//          multipart/form-data field name must be "file"
router.post(
  "/:courseId",
  protect,
  authorize("teacher", "admin"),
  resourceUpload.single("file"),
  async (req, res) => {
    try {
      const course = await Course.findById(req.params.courseId);
      if (!course) return res.status(404).json({ message: "Course not found" });

      if (req.user.role === "teacher" && String(course.teacher) !== String(req.user._id)) {
        return res.status(403).json({ message: "You can only upload to your own course" });
      }

      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded (field name must be 'file')" });
      }

      const { title, description } = req.body;

      const resource = await Resource.create({
        course: course._id,
        uploadedBy: req.user._id,
        title: title || req.file.originalname,
        description: description || "",
        fileName: req.file.originalname,
        filePath: `/uploads/resources/${req.file.filename}`,
        fileType: req.file.mimetype,
        fileSize: req.file.size,
      });

      res.status(201).json(resource);
    } catch (err) {
      res.status(500).json({ message: "Server error uploading resource", error: err.message });
    }
  }
);

// @route   GET /api/resources/:courseId
// @desc    List resources for a course (students must be enrolled, or teacher/admin)
router.get("/:courseId", protect, async (req, res) => {
  try {
    const course = await Course.findById(req.params.courseId);
    if (!course) return res.status(404).json({ message: "Course not found" });

    const isEnrolled = course.students.some((s) => String(s) === String(req.user._id));
    const isOwner = String(course.teacher) === String(req.user._id);

    if (req.user.role === "student" && !isEnrolled) {
      return res.status(403).json({ message: "You must join this class to view its resources" });
    }
    if (req.user.role === "teacher" && !isOwner) {
      return res.status(403).json({ message: "You can only view resources for your own course" });
    }

    const resources = await Resource.find({ course: course._id }).sort({ createdAt: -1 });
    res.json(resources);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// @route   GET /api/resources/download/:id
// @desc    Download a specific resource file
router.get("/download/:id", protect, async (req, res) => {
  try {
    const resource = await Resource.findById(req.params.id);
    if (!resource) return res.status(404).json({ message: "Resource not found" });

    const absolutePath = path.join(__dirname, "..", resource.filePath);
    if (!fs.existsSync(absolutePath)) {
      return res.status(404).json({ message: "File missing on server" });
    }

    res.download(absolutePath, resource.fileName);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// @route   DELETE /api/resources/:id
router.delete("/:id", protect, authorize("teacher", "admin"), async (req, res) => {
  try {
    const resource = await Resource.findById(req.params.id);
    if (!resource) return res.status(404).json({ message: "Resource not found" });

    const absolutePath = path.join(__dirname, "..", resource.filePath);
    if (fs.existsSync(absolutePath)) fs.unlinkSync(absolutePath);

    await resource.deleteOne();
    res.json({ message: "Resource deleted" });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

module.exports = router;
