const express = require("express");
const router = express.Router();

// @route   POST /api/contact
// @desc    Public contact form submission. In production you'd wire this to
//          nodemailer/SendGrid to actually email CONTACT_EMAIL; for now it
//          simply logs the message server-side and confirms receipt.
router.post("/", async (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ message: "Name, email and message are required" });
  }

  console.log("=== New Contact Us submission ===");
  console.log(`To: ${process.env.CONTACT_EMAIL}`);
  console.log(`From: ${name} <${email}>`);
  console.log(`Message: ${message}`);
  console.log("=================================");

  res.json({
    message: "Thanks for reaching out! We'll get back to you soon.",
    contactEmail: process.env.CONTACT_EMAIL,
  });
});

module.exports = router;
