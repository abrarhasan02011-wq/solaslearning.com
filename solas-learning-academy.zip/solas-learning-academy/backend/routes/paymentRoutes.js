const express = require("express");
const Stripe = require("stripe");
const Payment = require("../models/Payment");
const Course = require("../models/Course");
const { protect, authorize } = require("../middleware/auth");

const router = express.Router();

// Stripe is initialised lazily so the app can still boot without a real key
// during local development/demoing.
const stripe = process.env.STRIPE_SECRET_KEY
  ? new Stripe(process.env.STRIPE_SECRET_KEY)
  : null;

// @route   POST /api/payments/checkout
// @desc    Student: create a payment intent for a paid course, then confirm
//          on the frontend with Stripe Elements/Checkout.
router.post("/checkout", protect, authorize("student"), async (req, res) => {
  try {
    const { courseId } = req.body;
    const course = await Course.findById(courseId);
    if (!course) return res.status(404).json({ message: "Course not found" });
    if (course.price <= 0) {
      return res.status(400).json({ message: "This course is free, no payment needed" });
    }

    if (course.students.includes(req.user._id)) {
      return res.status(400).json({ message: "You are already enrolled" });
    }

    const amountInCents = Math.round(course.price * 100);

    let paymentIntent = null;
    if (stripe) {
      paymentIntent = await stripe.paymentIntents.create({
        amount: amountInCents,
        currency: "usd",
        metadata: {
          courseId: String(course._id),
          studentId: String(req.user._id),
        },
      });
    }

    const payment = await Payment.create({
      student: req.user._id,
      course: course._id,
      amount: amountInCents,
      currency: "usd",
      stripePaymentIntentId: paymentIntent ? paymentIntent.id : `demo_${Date.now()}`,
      status: stripe ? "pending" : "succeeded", // auto-succeed in demo mode (no Stripe key set)
    });

    // Demo mode (no Stripe key configured): enroll immediately so the
    // feature is fully testable without real payment credentials.
    if (!stripe) {
      course.students.push(req.user._id);
      await course.save();
      req.user.enrolledCourses.push(course._id);
      await req.user.save();
    }

    res.json({
      payment,
      clientSecret: paymentIntent ? paymentIntent.client_secret : null,
      demoMode: !stripe,
    });
  } catch (err) {
    res.status(500).json({ message: "Server error during checkout", error: err.message });
  }
});

// @route   POST /api/payments/confirm
// @desc    Confirm a payment succeeded (called by frontend after Stripe confirms,
//          or by a Stripe webhook in production) and enrol the student.
router.post("/confirm", protect, authorize("student"), async (req, res) => {
  try {
    const { paymentId } = req.body;
    const payment = await Payment.findById(paymentId);
    if (!payment) return res.status(404).json({ message: "Payment not found" });

    payment.status = "succeeded";
    await payment.save();

    const course = await Course.findById(payment.course);
    if (course && !course.students.includes(req.user._id)) {
      course.students.push(req.user._id);
      await course.save();
      req.user.enrolledCourses.push(course._id);
      await req.user.save();
    }

    res.json({ message: "Payment confirmed, you are now enrolled", course });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// @route   GET /api/payments/mine
router.get("/mine", protect, authorize("student"), async (req, res) => {
  const payments = await Payment.find({ student: req.user._id })
    .populate("course", "title price")
    .sort({ createdAt: -1 });
  res.json(payments);
});

// @route   GET /api/payments
// @desc    Admin: view all payments (revenue tracking)
router.get("/", protect, authorize("admin"), async (req, res) => {
  const payments = await Payment.find()
    .populate("student", "name email")
    .populate("course", "title price")
    .sort({ createdAt: -1 });
  res.json(payments);
});

module.exports = router;
