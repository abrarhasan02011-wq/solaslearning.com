const mongoose = require("mongoose");

const courseSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, default: "" },
    subject: { type: String, default: "General" },
    teacher: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    students: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    price: { type: Number, default: 0 }, // 0 = free course
    // A unique code students use to join the class/course
    joinCode: { type: String, required: true, unique: true },
    // Live class meeting link (Jitsi / Zoom / Google Meet etc.)
    meetingLink: { type: String, default: "" },
    schedule: { type: String, default: "" }, // e.g. "Mon/Wed/Fri 6:00 PM"
    thumbnail: { type: String, default: "" },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Course", courseSchema);
