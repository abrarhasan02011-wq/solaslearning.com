const multer = require("multer");
const path = require("path");
const fs = require("fs");

// Ensure a destination folder exists, create it if not
const ensureDir = (dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
};

// Factory that builds a multer instance which stores files under
// /uploads/<folderName>/ with a collision-safe filename.
const buildUploader = (folderName, allowedExtensions, maxSizeMB = 20) => {
  const destination = path.join(__dirname, "..", "uploads", folderName);
  ensureDir(destination);

  const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, destination),
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      const base = path
        .basename(file.originalname, ext)
        .replace(/[^a-zA-Z0-9-_]/g, "_")
        .slice(0, 50);
      const unique = `${base}-${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`;
      cb(null, unique);
    },
  });

  const fileFilter = (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!allowedExtensions || allowedExtensions.includes(ext)) {
      cb(null, true);
    } else {
      cb(
        new Error(
          `File type ${ext} is not allowed. Allowed types: ${allowedExtensions.join(", ")}`
        ),
        false
      );
    }
  };

  return multer({
    storage,
    fileFilter,
    limits: { fileSize: maxSizeMB * 1024 * 1024 },
  });
};

// Resources: docs, slides, pdfs, images, zipped material
const resourceUpload = buildUploader(
  "resources",
  [".pdf", ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx", ".txt", ".zip", ".png", ".jpg", ".jpeg", ".mp4"],
  50
);

// Assignments: submissions from students / attachments from teachers
const assignmentUpload = buildUploader(
  "assignments",
  [".pdf", ".doc", ".docx", ".zip", ".png", ".jpg", ".jpeg", ".txt"],
  25
);

module.exports = { resourceUpload, assignmentUpload };
