/**
 * Run once to create the first admin account:
 *   node seedAdmin.js
 *
 * Edit the values below before running, or set them via env vars:
 *   ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD
 */
require("dotenv").config();
const mongoose = require("mongoose");
const User = require("./models/User");

const run = async () => {
  await mongoose.connect(process.env.MONGO_URI);

  const name = process.env.ADMIN_NAME || "Solas Admin";
  const email = process.env.ADMIN_EMAIL || "admin@solaslearningacademy.com";
  const password = process.env.ADMIN_PASSWORD || "ChangeMe123!";

  const existing = await User.findOne({ email });
  if (existing) {
    console.log(`Admin with email ${email} already exists.`);
    process.exit(0);
  }

  const admin = await User.create({ name, email, password, role: "admin" });
  console.log("Admin account created:");
  console.log(`  Email: ${admin.email}`);
  console.log(`  Password: ${password}`);
  console.log("Please log in and change this password.");

  process.exit(0);
};

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
