# Solas Learning Academy — MERN LMS

A full-stack Learning Management System built with **MongoDB, Express, React, and Node.js**.

Features:
- 🔐 JWT auth with 3 roles: **Admin**, **Teacher**, **Student**
- 🎓 Teachers create classes, students join via a **class code** or by browsing courses
- 📁 **File upload system** (Multer) for course **resources** (notes/slides/videos) and **assignment** submissions
- 📝 Assignments with due dates, submissions, and grading/feedback
- 🎥 Live class joining via a teacher-provided meeting link (Zoom / Google Meet / Jitsi)
- 💳 Payment section for paid courses (Stripe-ready, with a working demo mode if no Stripe key is set)
- 🧑‍💼 Admin console for managing users, viewing all classes, and tracking revenue
- 📬 Contact Us page (emails routed to **abrarhasan02011@gmail.com**)

---

## Project Structure

```
solas-learning-academy/
├── backend/            # Express + MongoDB API
│   ├── config/db.js
│   ├── models/         # User, Course, Resource, Assignment, Submission, Payment
│   ├── middleware/      # auth.js (JWT + roles), upload.js (Multer file uploads)
│   ├── routes/          # auth, users, courses, resources, assignments, payments, contact
│   ├── uploads/          # uploaded files land here (resources/, assignments/)
│   ├── seedAdmin.js     # script to create the first admin account
│   └── server.js
└── frontend/            # React app
    └── src/
        ├── api/axios.js
        ├── context/AuthContext.js
        ├── components/  # Navbar, Footer, Layout, PrivateRoute
        └── pages/        # Home, Login, Register, Courses, CourseDetail,
                           # StudentDashboard, TeacherDashboard, AdminDashboard, ContactUs
```

---

## 1. Backend Setup

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env`:
- `MONGO_URI` — point to your local MongoDB or a MongoDB Atlas cluster
- `JWT_SECRET` — any long random string
- `STRIPE_SECRET_KEY` — optional. If left blank, the payment flow runs in **demo mode**
  (checkout auto-succeeds and enrolls the student immediately, so you can test the full
  flow without a real Stripe account).

Start MongoDB locally (if using a local instance):
```bash
mongod
```

Create the first admin account:
```bash
node seedAdmin.js
```
This prints an admin email/password (defaults: `admin@solaslearningacademy.com` / `ChangeMe123!`
unless you set `ADMIN_NAME`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` env vars first). Log in and change
the password by re-registering a new admin via database if needed — there's no self-serve admin
signup by design (admins are provisioned, not self-registered).

Run the API:
```bash
npm run dev      # with nodemon (auto-restarts)
# or
npm start
```

The API runs at `http://localhost:5000` and serves uploaded files at
`http://localhost:5000/uploads/...`.

---

## 2. Frontend Setup

```bash
cd frontend
npm install
cp .env.example .env
```

`.env` just needs:
```
REACT_APP_API_URL=http://localhost:5000/api
```

Run it:
```bash
npm start
```

The app opens at `http://localhost:3000`.

---

## 3. Using the App

1. **Register** as a Teacher, and separately as a Student (two browser sessions or
   incognito windows work well for testing).
2. As the **Teacher**, go to your dashboard → "Create New Class". Set a price of `0` for a
   free class, or any amount for a paid one. Add a meeting link (e.g. a free
   `https://meet.jit.si/your-room-name` room works instantly with no signup).
3. Copy the **join code** shown on your class card.
4. As the **Student**, go to Courses (or your dashboard) and enter the join code, or open the
   course page directly and click "Join"/"Pay & Join".
5. Once enrolled, the student can view **Resources** (uploaded by the teacher) and
   **Assignments** — submit files, and the teacher can grade them from the course page.
6. As the **Admin**, log in with the seeded admin account to view/manage all users, classes,
   and payments from `/admin`.

---

## 4. File Uploads — how it works

This is the core piece you asked about: `backend/middleware/upload.js` configures **Multer**
disk storage with:
- Separate folders for `resources/` and `assignments/`
- Collision-safe filenames (`originalname-timestamp-random.ext`)
- File-type whitelisting per upload type
- Size limits (50MB for resources, 25MB for assignment submissions)

Routes that use it:
- `POST /api/resources/:courseId` (field name `file`) — teacher uploads a resource
- `GET /api/resources/download/:id` — anyone enrolled can download it
- `POST /api/assignments/:courseId` (field name `attachment`) — teacher creates an assignment,
  optionally with an attached file
- `POST /api/assignments/:id/submit` (field name `file`) — student submits/resubmits their work
- `GET /api/assignments/download/:submissionId` — download a submission

---

## 5. Notes on the Payment Section

The payment route (`backend/routes/paymentRoutes.js`) is wired for **Stripe PaymentIntents**.
If you add a real `STRIPE_SECRET_KEY`, you'll want to also add Stripe Elements/Checkout on the
frontend to collect card details and call `stripe.confirmCardPayment(clientSecret)` before
hitting `/api/payments/confirm`. Without a Stripe key, the backend runs in **demo mode**, so
the whole paid-enrollment flow (checkout → enrolled) is testable end-to-end immediately.

---

## 6. Contact

Questions about this codebase can be sent to **abrarhasan02011@gmail.com** — this is also the
address wired into the app's Contact Us page and footer.
