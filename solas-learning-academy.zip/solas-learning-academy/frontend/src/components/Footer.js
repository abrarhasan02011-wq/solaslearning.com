import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div>
          <h4>Solas Learning Academy</h4>
          <p style={{ maxWidth: 260, fontSize: "0.88rem", opacity: 0.75 }}>
            Bringing light to learning — quality online classes, resources, and mentorship
            for students everywhere.
          </p>
        </div>
        <div>
          <h4>Quick Links</h4>
          <Link to="/courses">Browse Courses</Link>
          <Link to="/register">Sign Up</Link>
          <Link to="/login">Login</Link>
        </div>
        <div>
          <h4>Contact Us</h4>
          <a href="mailto:abrarhasan02011@gmail.com">abrarhasan02011@gmail.com</a>
          <Link to="/contact">Send us a message</Link>
        </div>
      </div>
      <div className="footer-bottom">
        © {new Date().getFullYear()} Solas Learning Academy. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
