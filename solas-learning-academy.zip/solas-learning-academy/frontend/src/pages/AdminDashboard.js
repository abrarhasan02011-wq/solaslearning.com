import React, { useEffect, useState } from "react";
import Layout from "../components/Layout";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

const AdminDashboard = () => {
  const { user } = useAuth();
  const [tab, setTab] = useState("users");
  const [users, setUsers] = useState([]);
  const [courses, setCourses] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);

  const load = async () => {
    try {
      const [{ data: u }, { data: c }, { data: p }] = await Promise.all([
        api.get("/users"),
        api.get("/courses"),
        api.get("/payments"),
      ]);
      setUsers(u);
      setCourses(c);
      setPayments(p);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const toggleActive = async (u) => {
    try {
      await api.patch(`/users/${u._id}/status`, { isActive: !u.isActive });
      setMsg({ type: "success", message: `${u.name} ${u.isActive ? "deactivated" : "activated"}` });
      load();
    } catch (err) {
      setMsg({ type: "error", message: err.response?.data?.message || "Failed to update user" });
    }
  };

  const totalRevenue = payments
    .filter((p) => p.status === "succeeded")
    .reduce((sum, p) => sum + p.amount, 0);

  return (
    <Layout>
      <div className="dashboard container">
        <div className="dashboard-header">
          <div>
            <h1>Admin Console</h1>
            <p>Welcome, {user.name}. Manage the whole academy from here.</p>
          </div>
        </div>

        <div className="stat-row">
          <div className="stat-card">
            <div className="stat-value">{users.length}</div>
            <div className="stat-label">Total Users</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">{courses.length}</div>
            <div className="stat-label">Total Classes</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">{payments.length}</div>
            <div className="stat-label">Payments</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">${(totalRevenue / 100).toFixed(2)}</div>
            <div className="stat-label">Total Revenue</div>
          </div>
        </div>

        {msg && (
          <div className={`alert alert-${msg.type === "success" ? "success" : "error"}`}>
            {msg.message}
          </div>
        )}

        <div className="tab-bar">
          <button className={tab === "users" ? "active" : ""} onClick={() => setTab("users")}>
            Users
          </button>
          <button className={tab === "courses" ? "active" : ""} onClick={() => setTab("courses")}>
            Classes
          </button>
          <button className={tab === "payments" ? "active" : ""} onClick={() => setTab("payments")}>
            Payments
          </button>
        </div>

        {loading ? (
          <div className="page-loading">Loading...</div>
        ) : (
          <>
            {tab === "users" &&
              users.map((u) => (
                <div className="list-item" key={u._id}>
                  <div className="list-item-main">
                    <h4>
                      {u.name}{" "}
                      <span className="badge badge-info" style={{ marginLeft: 6 }}>
                        {u.role}
                      </span>
                    </h4>
                    <p>{u.email}</p>
                  </div>
                  <div className="list-item-actions">
                    <span className={`badge ${u.isActive ? "badge-success" : "badge-danger"}`}>
                      {u.isActive ? "Active" : "Deactivated"}
                    </span>
                    <button className="btn btn-sm btn-secondary" onClick={() => toggleActive(u)}>
                      {u.isActive ? "Deactivate" : "Activate"}
                    </button>
                  </div>
                </div>
              ))}

            {tab === "courses" &&
              courses.map((c) => (
                <div className="list-item" key={c._id}>
                  <div className="list-item-main">
                    <h4>{c.title}</h4>
                    <p>
                      By {c.teacher?.name} &middot; {c.students?.length || 0} students &middot;{" "}
                      {c.price === 0 ? "Free" : `$${c.price.toFixed(2)}`}
                    </p>
                  </div>
                </div>
              ))}

            {tab === "payments" &&
              payments.map((p) => (
                <div className="list-item" key={p._id}>
                  <div className="list-item-main">
                    <h4>{p.course?.title}</h4>
                    <p>
                      {p.student?.name} &middot; ${(p.amount / 100).toFixed(2)} &middot;{" "}
                      {new Date(p.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <span
                    className={`badge ${
                      p.status === "succeeded"
                        ? "badge-success"
                        : p.status === "pending"
                        ? "badge-warning"
                        : "badge-danger"
                    }`}
                  >
                    {p.status}
                  </span>
                </div>
              ))}
          </>
        )}
      </div>
    </Layout>
  );
};

export default AdminDashboard;
