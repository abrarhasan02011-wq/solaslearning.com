import React, { useState } from "react";
import Layout from "../components/Layout";
import api from "../api/axios";

const ContactUs = () => {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setStatus(null);
    try {
      const { data } = await api.post("/contact", form);
      setStatus({ type: "success", message: data.message });
      setForm({ name: "", email: "", message: "" });
    } catch (err) {
      setStatus({
        type: "error",
        message: err.response?.data?.message || "Something went wrong. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <section className="section container">
        <h1 className="section-title">Contact Us</h1>
        <p className="section-subtitle">
          Have a question about a course, an assignment, or your account? Reach out — we're
          happy to help.
        </p>

        <div className="grid grid-2">
          <div className="card">
            <h3 style={{ marginTop: 0 }}>Send us a message</h3>
            {status && (
              <div className={`alert alert-${status.type === "success" ? "success" : "error"}`}>
                {status.message}
              </div>
            )}
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Your Name</label>
                <input name="name" value={form.name} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label>Your Email</label>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label>Message</label>
                <textarea name="message" value={form.message} onChange={handleChange} required />
              </div>
              <button className="btn btn-primary btn-block" disabled={loading}>
                {loading ? "Sending..." : "Send Message"}
              </button>
            </form>
          </div>

          <div className="card">
            <h3 style={{ marginTop: 0 }}>Reach us directly</h3>
            <p style={{ color: "var(--muted)" }}>
              Prefer email? Write to us directly and our team will respond as soon as possible.
            </p>
            <p>
              📧 Email:{" "}
              <a href="mailto:abrarhasan02011@gmail.com" style={{ color: "var(--navy)", fontWeight: 600 }}>
                abrarhasan02011@gmail.com
              </a>
            </p>
            <p style={{ color: "var(--muted)", fontSize: "0.9rem" }}>
              We typically respond within 1–2 business days.
            </p>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default ContactUs;
