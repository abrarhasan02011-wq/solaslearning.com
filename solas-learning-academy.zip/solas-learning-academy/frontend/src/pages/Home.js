import React from "react";
import { Link } from "react-router-dom";
import Layout from "../components/Layout";

const features = [
  {
    icon: "📚",
    title: "Rich Resources",
    desc: "Teachers upload notes, slides, and videos that students can access anytime, right from their course page.",
  },
  {
    icon: "📝",
    title: "Assignments & Grading",
    desc: "Create assignments with due dates, collect student submissions, and grade them with feedback — all in one place.",
  },
  {
    icon: "🎥",
    title: "Live Class Joining",
    desc: "Students join live classes instantly using a simple class code or a direct meeting link shared by their teacher.",
  },
  {
    icon: "💳",
    title: "Secure Payments",
    desc: "Enroll in premium courses with a smooth, secure checkout — free courses can be joined instantly.",
  },
  {
    icon: "🧑‍🏫",
    title: "Role-Based Dashboards",
    desc: "Purpose-built dashboards for Admins, Teachers, and Students, each with the tools they actually need.",
  },
  {
    icon: "🔒",
    title: "Secure Accounts",
    desc: "JWT-based authentication keeps every account and every classroom protected.",
  },
];

const Home = () => {
  return (
    <Layout>
      <section className="hero">
        <div className="container">
          <h1>Welcome to Solas Learning Academy</h1>
          <p>
            A modern learning management system where teachers teach, students learn, and
            growth happens — bringing light ("solas") to every learner's journey.
          </p>
          <div className="hero-actions">
            <Link to="/register" className="btn btn-primary">
              Join as a Student
            </Link>
            <Link to="/register" className="btn btn-outline">
              Become a Teacher
            </Link>
          </div>
        </div>
      </section>

      <section className="section container">
        <h2 className="section-title">Everything your classroom needs</h2>
        <p className="section-subtitle">
          Built for teachers, students, and administrators alike.
        </p>
        <div className="grid grid-3">
          {features.map((f) => (
            <div className="card feature-card" key={f.title}>
              <div className="feature-icon">{f.icon}</div>
              <h3>{f.title}</h3>
              <p>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section container" style={{ textAlign: "center" }}>
        <div className="card" style={{ padding: 40 }}>
          <h2 className="section-title">Ready to get started?</h2>
          <p className="section-subtitle">
            Create your free account and join your first class in minutes.
          </p>
          <Link to="/register" className="btn btn-primary">
            Create Free Account
          </Link>
        </div>
      </section>
    </Layout>
  );
};

export default Home;
