import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import Layout from "../components/Layout";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

const CourseDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [course, setCourse] = useState(null);
  const [resources, setResources] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [tab, setTab] = useState("overview");
  const [msg, setMsg] = useState(null);

  // upload forms
  const [resourceForm, setResourceForm] = useState({ title: "", description: "", file: null });
  const [assignmentForm, setAssignmentForm] = useState({
    title: "",
    description: "",
    dueDate: "",
    maxMarks: 100,
  });
  const [submitFiles, setSubmitFiles] = useState({}); // { assignmentId: File }

  const isEnrolled =
    course && user && course.students?.some((s) => (s._id || s) === user.id);
  const isOwner = course && user && (course.teacher?._id || course.teacher) === user.id;
  const canSeeContent = user && (user.role !== "student" || isEnrolled) ? true : false;

  const loadAll = useCallback(async () => {
    try {
      const { data: courseData } = await api.get(`/courses/${id}`);
      setCourse(courseData);

      const enrolled =
        user &&
        (user.role !== "student" ||
          courseData.students?.some((s) => (s._id || s) === user.id));

      if (user && enrolled) {
        const [{ data: res }, { data: asg }] = await Promise.all([
          api.get(`/resources/${id}`).catch(() => ({ data: [] })),
          api.get(`/assignments/${id}`).catch(() => ({ data: [] })),
        ]);
        setResources(res);
        setAssignments(asg);
      }
    } catch (err) {
      console.error(err);
    }
  }, [id, user]);

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const handlePayAndJoin = async () => {
    setMsg(null);
    try {
      const { data } = await api.post("/payments/checkout", { courseId: id });
      if (data.demoMode) {
        setMsg({ type: "success", message: "Payment successful (demo mode) — you're enrolled!" });
      } else {
        // In a real deployment you'd redirect to Stripe Checkout / confirm with Elements here
        await api.post("/payments/confirm", { paymentId: data.payment._id });
        setMsg({ type: "success", message: "Payment confirmed — you're enrolled!" });
      }
      loadAll();
    } catch (err) {
      setMsg({ type: "error", message: err.response?.data?.message || "Payment failed" });
    }
  };

  const handleFreeJoin = async () => {
    setMsg(null);
    try {
      const { data } = await api.post("/courses/join", { joinCode: course.joinCode });
      setMsg({ type: "success", message: data.message });
      loadAll();
    } catch (err) {
      setMsg({ type: "error", message: err.response?.data?.message || "Could not join" });
    }
  };

  const handleUploadResource = async (e) => {
    e.preventDefault();
    if (!resourceForm.file) return setMsg({ type: "error", message: "Please choose a file" });
    const fd = new FormData();
    fd.append("title", resourceForm.title || resourceForm.file.name);
    fd.append("description", resourceForm.description);
    fd.append("file", resourceForm.file);
    try {
      await api.post(`/resources/${id}`, fd, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setResourceForm({ title: "", description: "", file: null });
      setMsg({ type: "success", message: "Resource uploaded" });
      loadAll();
    } catch (err) {
      setMsg({ type: "error", message: err.response?.data?.message || "Upload failed" });
    }
  };

  const handleCreateAssignment = async (e) => {
    e.preventDefault();
    try {
      await api.post(`/assignments/${id}`, assignmentForm);
      setAssignmentForm({ title: "", description: "", dueDate: "", maxMarks: 100 });
      setMsg({ type: "success", message: "Assignment created" });
      loadAll();
    } catch (err) {
      setMsg({ type: "error", message: err.response?.data?.message || "Failed to create assignment" });
    }
  };

  const handleSubmitAssignment = async (assignmentId) => {
    const file = submitFiles[assignmentId];
    if (!file) return setMsg({ type: "error", message: "Choose a file to submit first" });
    const fd = new FormData();
    fd.append("file", file);
    try {
      await api.post(`/assignments/${assignmentId}/submit`, fd, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setMsg({ type: "success", message: "Assignment submitted!" });
    } catch (err) {
      setMsg({ type: "error", message: err.response?.data?.message || "Submission failed" });
    }
  };

  if (!course) return <Layout><div className="page-loading">Loading course...</div></Layout>;

  return (
    <Layout>
      <section className="section container">
        <div className="dashboard-header">
          <div>
            <h1 style={{ margin: 0 }}>{course.title}</h1>
            <p>{course.description}</p>
            <p style={{ fontSize: "0.85rem", color: "var(--muted)" }}>
              Taught by {course.teacher?.name} &middot;{" "}
              <span className={`course-price-tag ${course.price === 0 ? "free" : ""}`}>
                {course.price === 0 ? "Free" : `$${course.price.toFixed(2)}`}
              </span>
            </p>
          </div>
          {isOwner && (
            <span className="join-code-pill">Join Code: {course.joinCode}</span>
          )}
        </div>

        {msg && (
          <div className={`alert alert-${msg.type === "success" ? "success" : "error"}`}>
            {msg.message}
          </div>
        )}

        {user?.role === "student" && !isEnrolled && (
          <div className="card" style={{ marginBottom: 24 }}>
            <h3 style={{ marginTop: 0 }}>
              {course.price === 0 ? "Join this free class" : "Enroll in this class"}
            </h3>
            <p style={{ color: "var(--muted)" }}>
              {course.price === 0
                ? "This class is free — join instantly to access resources and assignments."
                : `Pay $${course.price.toFixed(2)} to unlock resources, assignments, and live class access.`}
            </p>
            {course.price === 0 ? (
              <button className="btn btn-primary" onClick={handleFreeJoin}>
                Join Class
              </button>
            ) : (
              <button className="btn btn-primary" onClick={handlePayAndJoin}>
                Pay ${course.price.toFixed(2)} &amp; Join
              </button>
            )}
          </div>
        )}

        {canSeeContent && (
          <>
            <div className="tab-bar">
              <button className={tab === "overview" ? "active" : ""} onClick={() => setTab("overview")}>
                Overview
              </button>
              <button className={tab === "resources" ? "active" : ""} onClick={() => setTab("resources")}>
                Resources
              </button>
              <button className={tab === "assignments" ? "active" : ""} onClick={() => setTab("assignments")}>
                Assignments
              </button>
            </div>

            {tab === "overview" && (
              <div className="card">
                <h3 style={{ marginTop: 0 }}>Live Class</h3>
                {course.schedule && <p>🗓️ Schedule: {course.schedule}</p>}
                {course.meetingLink ? (
                  <div className="meeting-box">
                    <p style={{ margin: "0 0 10px" }}>Class is ready to join.</p>
                    <a
                      href={course.meetingLink}
                      target="_blank"
                      rel="noreferrer"
                      className="btn btn-primary"
                    >
                      Join Live Class
                    </a>
                  </div>
                ) : (
                  <p style={{ color: "var(--muted)" }}>
                    No live meeting link has been posted yet. Check back before your class time.
                  </p>
                )}
              </div>
            )}

            {tab === "resources" && (
              <div>
                {(isOwner || user.role === "admin") && (
                  <div className="card" style={{ marginBottom: 20 }}>
                    <h3 style={{ marginTop: 0 }}>Upload a Resource</h3>
                    <form onSubmit={handleUploadResource}>
                      <div className="form-row">
                        <div className="form-group">
                          <label>Title</label>
                          <input
                            value={resourceForm.title}
                            onChange={(e) => setResourceForm({ ...resourceForm, title: e.target.value })}
                            placeholder="e.g. Week 1 Slides"
                          />
                        </div>
                        <div className="form-group">
                          <label>Description</label>
                          <input
                            value={resourceForm.description}
                            onChange={(e) =>
                              setResourceForm({ ...resourceForm, description: e.target.value })
                            }
                            placeholder="Optional"
                          />
                        </div>
                      </div>
                      <div className="form-group">
                        <label>File</label>
                        <input
                          type="file"
                          onChange={(e) => setResourceForm({ ...resourceForm, file: e.target.files[0] })}
                        />
                      </div>
                      <button className="btn btn-secondary">Upload</button>
                    </form>
                  </div>
                )}

                {resources.length === 0 ? (
                  <div className="empty-state">No resources uploaded yet.</div>
                ) : (
                  resources.map((r) => (
                    <div className="list-item" key={r._id}>
                      <div className="list-item-main">
                        <h4>{r.title}</h4>
                        <p>{r.description}</p>
                      </div>
                      <div className="list-item-actions">
                        <a
                          className="btn btn-secondary btn-sm"
                          href={`${process.env.REACT_APP_API_URL || "http://localhost:5000/api"}/resources/download/${r._id}`}
                        >
                          Download
                        </a>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {tab === "assignments" && (
              <div>
                {(isOwner || user.role === "admin") && (
                  <div className="card" style={{ marginBottom: 20 }}>
                    <h3 style={{ marginTop: 0 }}>Create Assignment</h3>
                    <form onSubmit={handleCreateAssignment}>
                      <div className="form-group">
                        <label>Title</label>
                        <input
                          value={assignmentForm.title}
                          onChange={(e) =>
                            setAssignmentForm({ ...assignmentForm, title: e.target.value })
                          }
                          required
                        />
                      </div>
                      <div className="form-group">
                        <label>Description</label>
                        <textarea
                          value={assignmentForm.description}
                          onChange={(e) =>
                            setAssignmentForm({ ...assignmentForm, description: e.target.value })
                          }
                        />
                      </div>
                      <div className="form-row">
                        <div className="form-group">
                          <label>Due Date</label>
                          <input
                            type="date"
                            value={assignmentForm.dueDate}
                            onChange={(e) =>
                              setAssignmentForm({ ...assignmentForm, dueDate: e.target.value })
                            }
                            required
                          />
                        </div>
                        <div className="form-group">
                          <label>Max Marks</label>
                          <input
                            type="number"
                            value={assignmentForm.maxMarks}
                            onChange={(e) =>
                              setAssignmentForm({ ...assignmentForm, maxMarks: e.target.value })
                            }
                          />
                        </div>
                      </div>
                      <button className="btn btn-secondary">Create Assignment</button>
                    </form>
                  </div>
                )}

                {assignments.length === 0 ? (
                  <div className="empty-state">No assignments posted yet.</div>
                ) : (
                  assignments.map((a) => (
                    <div className="list-item" key={a._id} style={{ alignItems: "flex-start" }}>
                      <div className="list-item-main">
                        <h4>{a.title}</h4>
                        <p>{a.description}</p>
                        <p>
                          Due: {new Date(a.dueDate).toLocaleDateString()} &middot; Max Marks:{" "}
                          {a.maxMarks}
                        </p>
                      </div>
                      {user.role === "student" && (
                        <div className="list-item-actions" style={{ flexDirection: "column", alignItems: "flex-end" }}>
                          <input
                            type="file"
                            onChange={(e) =>
                              setSubmitFiles({ ...submitFiles, [a._id]: e.target.files[0] })
                            }
                          />
                          <button
                            className="btn btn-primary btn-sm"
                            onClick={() => handleSubmitAssignment(a._id)}
                          >
                            Submit Work
                          </button>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            )}
          </>
        )}
      </section>
    </Layout>
  );
};

export default CourseDetail;
