import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Layout from "../components/Layout";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

const StudentDashboard = () => {
  const { user } = useAuth();
  const [courses, setCourses] = useState([]);
  const [payments, setPayments] = useState([]);
  const [joinCode, setJoinCode] = useState("");
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      const [{ data: myCourses }, { data: myPayments }] = await Promise.all([
        api.get("/courses/mine"),
        api.get("/payments/mine"),
      ]);
      setCourses(myCourses);
      setPayments(myPayments);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleJoin = async (e) => {
    e.preventDefault();
    setMsg(null);
    try {
      const { data } = await api.post("/courses/join", { joinCode });
      setMsg({ type: "success", message: data.message });
      setJoinCode("");
      load();
    } catch (err) {
      setMsg({
        type: "error",
        message:
          err.response?.status === 402
            ? "This is a paid class — open it from the Courses page to pay and join."
            : err.response?.data?.message || "Could not join class",
      });
    }
  };

  return (
    <Layout>
      <div className="dashboard container">
        <div className="dashboard-header">
          <div>
            <h1>Welcome back, {user.name.split(" ")[0]}</h1>
            <p>Here's what's happening across your classes.</p>
          </div>
        </div>

        <div className="stat-row">
          <div className="stat-card">
            <div className="stat-value">{courses.length}</div>
            <div className="stat-label">Enrolled Classes</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">
              {payments.filter((p) => p.status === "succeeded").length}
            </div>
            <div className="stat-label">Payments Made</div>
          </div>
        </div>

        <div className="card" style={{ marginBottom: 30 }}>
          <h3 style={{ marginTop: 0 }}>Join a New Class</h3>
          {msg && (
            <div className={`alert alert-${msg.type === "success" ? "success" : "error"}`}>
              {msg.message}
            </div>
          )}
          <form onSubmit={handleJoin} style={{ display: "flex", gap: 10 }}>
            <input
              placeholder="Enter class join code"
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
              style={{ flex: 1, padding: "10px 12px", border: "1px solid var(--border)", borderRadius: 8 }}
            />
            <button className="btn btn-primary">Join</button>
          </form>
        </div>

        <h2 className="section-title" style={{ fontSize: "1.3rem" }}>
          My Classes
        </h2>
        {loading ? (
          <div className="page-loading">Loading...</div>
        ) : courses.length === 0 ? (
          <div className="empty-state">
            You haven't joined any classes yet. Browse <Link to="/courses">Courses</Link> or use
            a join code above.
          </div>
        ) : (
          <div className="grid grid-3">
            {courses.map((c) => (
              <div className="card" key={c._id}>
                <h3 style={{ marginTop: 0 }}>{c.title}</h3>
                <p style={{ color: "var(--muted)", fontSize: "0.9rem" }}>
                  Taught by {c.teacher?.name}
                </p>
                <Link to={`/courses/${c._id}`} className="btn btn-secondary btn-sm">
                  Go to Class
                </Link>
              </div>
            ))}
          </div>
        )}

        <h2 className="section-title" style={{ fontSize: "1.3rem", marginTop: 40 }}>
          Payment History
        </h2>
        {payments.length === 0 ? (
          <div className="empty-state">No payments yet.</div>
        ) : (
          payments.map((p) => (
            <div className="list-item" key={p._id}>
              <div className="list-item-main">
                <h4>{p.course?.title}</h4>
                <p>${(p.amount / 100).toFixed(2)} &middot; {new Date(p.createdAt).toLocaleDateString()}</p>
              </div>
              <span
                className={`badge ${
                  p.status === "succeeded"
                    ? "badge-success"
                    : p.status === "pending"
                    ? "badge-warning"
                    : "badge-danger"
                }`}
              >
                {p.status}
              </span>
            </div>
          ))
        )}
      </div>
    </Layout>
  );
};

export default StudentDashboard;
