import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Layout from "../components/Layout";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

const Courses = () => {
  const { user } = useAuth();
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [joinCode, setJoinCode] = useState("");
  const [joinMsg, setJoinMsg] = useState(null);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const { data } = await api.get("/courses");
        setCourses(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchCourses();
  }, []);

  const handleJoin = async (e) => {
    e.preventDefault();
    setJoinMsg(null);
    try {
      const { data } = await api.post("/courses/join", { joinCode });
      setJoinMsg({ type: "success", message: data.message });
      setJoinCode("");
    } catch (err) {
      if (err.response?.status === 402) {
        setJoinMsg({
          type: "error",
          message: `This is a paid class ($${(err.response.data.coursePrice).toFixed(
            2
          )}). Visit the course page to pay and join.`,
        });
      } else {
        setJoinMsg({
          type: "error",
          message: err.response?.data?.message || "Could not join class",
        });
      }
    }
  };

  return (
    <Layout>
      <section className="section container">
        <h1 className="section-title">Explore Courses</h1>
        <p className="section-subtitle">
          Browse available classes at Solas Learning Academy, or jump straight into a class
          you've already been given a code for.
        </p>

        {user && user.role === "student" && (
          <div className="card" style={{ marginBottom: 30 }}>
            <h3 style={{ marginTop: 0 }}>Have a class code?</h3>
            {joinMsg && (
              <div className={`alert alert-${joinMsg.type === "success" ? "success" : "error"}`}>
                {joinMsg.message}
              </div>
            )}
            <form onSubmit={handleJoin} style={{ display: "flex", gap: 10 }}>
              <input
                placeholder="e.g. A1B2C3"
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                style={{
                  flex: 1,
                  padding: "10px 12px",
                  border: "1px solid var(--border)",
                  borderRadius: 8,
                }}
              />
              <button className="btn btn-primary">Join Class</button>
            </form>
          </div>
        )}

        {loading ? (
          <div className="page-loading">Loading courses...</div>
        ) : courses.length === 0 ? (
          <div className="empty-state">No courses available yet. Check back soon!</div>
        ) : (
          <div className="grid grid-3">
            {courses.map((c) => (
              <div className="card" key={c._id}>
                <h3 style={{ marginTop: 0 }}>{c.title}</h3>
                <p style={{ color: "var(--muted)", fontSize: "0.9rem" }}>
                  {c.description?.slice(0, 100) || "No description provided."}
                </p>
                <p style={{ fontSize: "0.85rem", color: "var(--muted)" }}>
                  Taught by {c.teacher?.name || "TBA"}
                </p>
                <p>
                  <span className={`course-price-tag ${c.price === 0 ? "free" : ""}`}>
                    {c.price === 0 ? "Free" : `$${c.price.toFixed(2)}`}
                  </span>
                </p>
                <Link to={`/courses/${c._id}`} className="btn btn-secondary btn-sm">
                  View Details
                </Link>
              </div>
            ))}
          </div>
        )}
      </section>
    </Layout>
  );
};

export default Courses;
