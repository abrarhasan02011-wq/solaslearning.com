import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Layout from "../components/Layout";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

const emptyCourseForm = {
  title: "",
  description: "",
  subject: "",
  price: 0,
  meetingLink: "",
  schedule: "",
};

const TeacherDashboard = () => {
  const { user } = useAuth();
  const [courses, setCourses] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyCourseForm);
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      const { data } = await api.get("/courses/mine");
      setCourses(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    setMsg(null);
    try {
      await api.post("/courses", { ...form, price: Number(form.price) });
      setMsg({ type: "success", message: "Class created successfully!" });
      setForm(emptyCourseForm);
      setShowForm(false);
      load();
    } catch (err) {
      setMsg({ type: "error", message: err.response?.data?.message || "Failed to create class" });
    }
  };

  const totalStudents = courses.reduce((sum, c) => sum + (c.students?.length || 0), 0);

  return (
    <Layout>
      <div className="dashboard container">
        <div className="dashboard-header">
          <div>
            <h1>Hello, {user.name.split(" ")[0]}</h1>
            <p>Manage your classes, resources, and assignments.</p>
          </div>
          <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>
            {showForm ? "Cancel" : "+ Create New Class"}
          </button>
        </div>

        <div className="stat-row">
          <div className="stat-card">
            <div className="stat-value">{courses.length}</div>
            <div className="stat-label">Classes</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">{totalStudents}</div>
            <div className="stat-label">Total Students</div>
          </div>
        </div>

        {msg && (
          <div className={`alert alert-${msg.type === "success" ? "success" : "error"}`}>
            {msg.message}
          </div>
        )}

        {showForm && (
          <div className="card" style={{ marginBottom: 30 }}>
            <h3 style={{ marginTop: 0 }}>Create a New Class</h3>
            <form onSubmit={handleCreate}>
              <div className="form-row">
                <div className="form-group">
                  <label>Title</label>
                  <input
                    value={form.title}
                    onChange={(e) => setForm({ ...form, title: e.target.value })}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Subject</label>
                  <input
                    value={form.subject}
                    onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    placeholder="e.g. Mathematics"
                  />
                </div>
              </div>
              <div className="form-group">
                <label>Description</label>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Price (USD, 0 = free)</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={form.price}
                    onChange={(e) => setForm({ ...form, price: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>Schedule</label>
                  <input
                    value={form.schedule}
                    onChange={(e) => setForm({ ...form, schedule: e.target.value })}
                    placeholder="Mon/Wed/Fri 6:00 PM"
                  />
                </div>
              </div>
              <div className="form-group">
                <label>Meeting Link (Zoom / Google Meet / Jitsi)</label>
                <input
                  value={form.meetingLink}
                  onChange={(e) => setForm({ ...form, meetingLink: e.target.value })}
                  placeholder="https://meet.jit.si/your-room-name"
                />
              </div>
              <button className="btn btn-secondary">Create Class</button>
            </form>
          </div>
        )}

        <h2 className="section-title" style={{ fontSize: "1.3rem" }}>
          My Classes
        </h2>
        {loading ? (
          <div className="page-loading">Loading...</div>
        ) : courses.length === 0 ? (
          <div className="empty-state">You haven't created any classes yet.</div>
        ) : (
          courses.map((c) => (
            <div className="list-item" key={c._id}>
              <div className="list-item-main">
                <h4>{c.title}</h4>
                <p>
                  {c.students?.length || 0} students &middot;{" "}
                  <span className="join-code-pill">{c.joinCode}</span> &middot;{" "}
                  {c.price === 0 ? "Free" : `$${c.price.toFixed(2)}`}
                </p>
              </div>
              <div className="list-item-actions">
                <Link to={`/courses/${c._id}`} className="btn btn-secondary btn-sm">
                  Manage
                </Link>
              </div>
            </div>
          ))
        )}
      </div>
    </Layout>
  );
};

export default TeacherDashboard;
